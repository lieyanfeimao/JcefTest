document.addEventListener('DOMContentLoaded', function () {
    const tocLinks = document.querySelectorAll('.toc-nav .nav-link');
    const sections = document.querySelectorAll('.content-main h2');

    var saveKey='tree-menu-states'+aid;

    // 点击平滑滚动
    tocLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                window.scrollTo({ top: targetSection.offsetTop - 20, behavior: 'smooth' });
            }
        });
    });

    // 滚动监听高亮
    window.addEventListener('scroll', () => {
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 50;
            if (window.scrollY >= sectionTop) {
                current = section.getAttribute('id');
            }
        });

        tocLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === '#' + current) {
                link.classList.add('active');
            }
        });
    });
	
	
	// 1. 核心兼容逻辑：将 UEditor 的 <pre> 转换为高亮库需要的 <pre><code> 结构
    function normalizeUeditorCode() {
        // const allPre = document.querySelectorAll('.content-main pre');
        //
        // allPre.forEach(pre => {
        //     // 如果内部已经有 <code> 标签，说明已经是标准结构，跳过
        //     if (pre.querySelector('code')) return;
        //
        //     // 提取原有的纯文本内容
        //     const codeContent = pre.innerHTML;
        //
        //     // 尝试自动识别语言（简单示例：根据内容特征判断）
        //     let langClass = 'language-plaintext'; // 默认纯文本
        //     if (codeContent.includes('function') || codeContent.includes('const')) langClass = 'language-js';
        //     if (codeContent.includes('def ') || codeContent.includes('import ')) langClass = 'language-python';
        //     if (codeContent.includes('SELECT') || codeContent.includes('FROM')) langClass = 'language-sql';
        //
        //     // 重构内部结构，并保留 UEditor 可能生成的原有类名
        //     pre.innerHTML = `<code class="${langClass}">${codeContent}</code>`;
        // });


        document.querySelectorAll('.content-main pre').forEach(pre => {
            // 1. 移除可能存在的强制不换行内联样式
            pre.style.whiteSpace = 'pre-wrap';

            // 2. 检查是否包含 SyntaxHighlighter 的 brush 属性
            const brushMatch = pre.className.match(/brush:\s*([^;]+)/);

            if (brushMatch) {
                const brushValue = brushMatch[1].trim().toLowerCase();

                // 3. 将 SyntaxHighlighter 的语言标识转换为 Prism.js 的格式
                // 例如：brush:js -> language-javascript, brush:xml -> language-markup
                let prismLang = brushValue;
                if (brushValue === 'js') prismLang = 'javascript';
                if (brushValue === 'xml' || brushValue === 'html') prismLang = 'markup';
                if (brushValue === 'py') prismLang = 'python';
                if (brushValue === 'cs') prismLang = 'csharp';

                // 4. 生成 Prism 需要的类名
                const prismClass = `language-${prismLang}`;

                // 5. 如果 pre 内部还没有 <code> 标签，动态创建一个
                let codeEl = pre.querySelector('code');
                if (!codeEl) {
                    codeEl = document.createElement('code');
                    // 将 pre 内部的纯文本或 HTML 节点转移到 code 标签内
                    while (pre.firstChild) {
                        codeEl.appendChild(pre.firstChild);
                    }
                    pre.appendChild(codeEl);
                }

                // 6. 给 <code> 标签加上 Prism 的类名
                codeEl.className = prismClass;
            }
        });

    }
	
	// 1. 核心：初始化所有代码块的复制按钮
    function initCopyButtons() {
        const allPre = document.querySelectorAll('.content-main pre');
        
        allPre.forEach(pre => {
            // 防止重复添加（例如页面刷新时）
            if (pre.querySelector('.copy-btn')) return;

            const button = document.createElement('button');
            button.className = 'copy-btn';
            button.textContent = '复制';
            button.setAttribute('aria-label', '复制代码');
            pre.appendChild(button);

            // 绑定点击事件
            button.addEventListener('click', async () => {
                // 获取代码内容：优先获取 <code> 标签的纯文本，否则获取 <pre> 的纯文本
                const codeElement = pre.querySelector('code');
                const codeText = codeElement ? codeElement.textContent : pre.textContent;

                try {
                    // 使用现代 Clipboard API 写入剪贴板
                    await navigator.clipboard.writeText(codeText);
                    
                    // 提供视觉反馈
                    button.textContent = '已复制!';
                    button.classList.add('copied');
                    
                    // 2秒后恢复按钮状态
                    setTimeout(() => {
                        button.textContent = '复制';
                        button.classList.remove('copied');
                    }, 2000);
                } catch (err) {
                    console.error('复制失败:', err);
                    button.textContent = '失败';
                    setTimeout(() => { button.textContent = '复制'; }, 2000);
                }
            });
        });
    }
	
	// 1. 树状菜单初始化
    function initTreeMenu() {
        const treeItems = document.querySelectorAll('.nav-item.has-children');

        // 读取本地存储的展开状态
        const openStates = JSON.parse(localStorage.getItem(saveKey) || '{}');

        treeItems.forEach((item, index) => {
            const key = `tree-item-${index}`;
            
            // 恢复上次的展开状态
            if (openStates[key] === true) {
                item.classList.add('open');
            }

            // 绑定点击事件
            const link = item.querySelector(':scope > .nav-link');
            link.addEventListener('click', (e) => {
                e.preventDefault(); // 阻止默认跳转
                item.classList.toggle('open');
                
                // 保存当前状态到本地存储
                openStates[key] = item.classList.contains('open');
                localStorage.setItem(saveKey, JSON.stringify(openStates));
            });
        });

        const navLinkItems = document.querySelectorAll('a.nav-link');
        navLinkItems.forEach((item, index) => {
            console.log(item.getAttribute("tid"));
            if(tid==item.getAttribute("tid")){
                console.log(tid);
                item.classList.add('active');
            }
        });

    }
	
	// 1. 动态创建并控制夜间模式按钮
    function initThemeToggle() {
        const body = document.body;

        // 动态创建按钮
        const themeBtn = document.createElement('button');
        themeBtn.id = 'theme-toggle-btn';
        themeBtn.setAttribute('aria-label', '切换夜间模式');
        document.body.appendChild(themeBtn); // 将按钮添加到页面中

        // 读取本地存储的主题状态
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            body.classList.add('dark-mode');
            themeBtn.textContent = '☀️'; // 夜间模式显示太阳图标
        } else {
            themeBtn.textContent = '🌙'; // 日间模式显示月亮图标
        }

        // 绑定点击事件
        themeBtn.addEventListener('click', () => {
            body.classList.toggle('dark-mode');
            const isDark = body.classList.contains('dark-mode');
            
            // 更新按钮图标和保存状态
            themeBtn.textContent = isDark ? '☀️' : '🌙';
            localStorage.setItem('theme', isDark ? 'dark' : 'light');
        });
    }
	
	// 1. 动态创建并控制返回顶部按钮
    function initBackToTop() {
        // 动态创建按钮
        const btn = document.createElement('button');
        btn.id = 'back-to-top-btn';
        btn.innerHTML = '↑'; // 使用箭头符号
        btn.setAttribute('aria-label', '返回顶部');
        document.body.appendChild(btn);

        // 监听页面滚动事件
        window.addEventListener('scroll', () => {
            // 当页面向下滚动超过 300px 时，显示按钮
            if (window.scrollY > 300) {
                btn.classList.add('visible');
            } else {
                btn.classList.remove('visible');
            }
        });

        // 点击按钮平滑回到顶部
        btn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth' // 核心：平滑滚动
            });
        });
    }
	
	// 1. 初始化 TOC 滚动监听与树形展开
    function initTocScrollSpy() {
        const tocItems = document.querySelectorAll('.sidebar-toc .toc-item');
        const headings = document.querySelectorAll('.content-main h2, .content-main h3, .content-main div');

        if (!tocItems.length || !headings.length) return;

        window.addEventListener('scroll', () => {
            let currentId = '';

            // 找到当前视口中的标题
            headings.forEach(heading => {
//				console.log(window.scrollY+" >> "+heading.offsetTop+" | "+(heading.offsetTop - 100));
                // 减去一点偏移量，让高亮更提前触发
                if (window.scrollY >= heading.offsetTop - 100) {
					let eid=heading.getAttribute('id');
                    if(eid!=null && eid!="") currentId = eid;
                }
            });

            // 清除所有 active 状态
            tocItems.forEach(item => item.classList.remove('active'));

            // 如果找到了当前标题，给对应的 TOC 节点加上 active
            if (currentId) {
                const activeLink = document.querySelector(`.toc-link[href="#${currentId}"]`);
				if (activeLink) {
					// 核心修复：给当前链接所在的 <li> 加上 active
					const currentTocItem = activeLink.closest('.toc-item');
					if (currentTocItem) {
						currentTocItem.classList.add('active');
						
						// 核心修复：向上遍历所有祖先 <li>，确保折叠的父级菜单也被展开
						let parentItem = currentTocItem.parentElement.closest('.toc-item');
						while (parentItem) {
							parentItem.classList.add('active');
							parentItem = parentItem.parentElement.closest('.toc-item');
						}
					}
				}
            }
        });
    }
	
	// 1. 初始化左侧菜单点击高亮
    function initMenuActiveState() {
        const menuItems = document.querySelectorAll('.sidebar-left .nav-item .nav-link');
        
        menuItems.forEach(item => {
            item.addEventListener('click', function () {
                // 1. 移除所有菜单项的 active 状态
                menuItems.forEach(el => el.classList.remove('active'));
                
                // 2. 给当前点击的菜单项添加 active 状态
                this.classList.add('active');
            });
        });
    }
	
	// 2. 初始化执行
    normalizeUeditorCode(); // 先转换结构
    Prism.highlightAll();   // 再触发 Prism.js 高亮
	initCopyButtons();      // 3. 【新增】注入复制按钮
	initTreeMenu(); // 【新增】初始化树状菜单
	initThemeToggle(); // 【新增】初始化主题切换
	
	initBackToTop(); // 【新增】初始化返回顶部按钮
	initTocScrollSpy(); // 【新增】初始化 TOC 滚动与展开
	
	initMenuActiveState(); // 【新增】初始化菜单点击高亮
});

