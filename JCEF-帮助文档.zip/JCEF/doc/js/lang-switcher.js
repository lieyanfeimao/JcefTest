document.addEventListener('DOMContentLoaded', function () {
    // 1. 定义语言配置映射
    const langConfig = {
		yi: { label: '🌐 译文', name: '译文' },
        yuan: { label: '🌐 原文', name: '原文' },
        yiyuan: { label: '🌐 原文/译文', name: '📖 原文/译文' }
    };

    // 2. 获取当前语言状态（默认双语）
    let currentLang = localStorage.getItem('doc-lang') || 'yi';

    // 3. 核心：切换 body 类名来控制显示
    function applyLanguage(lang) {
        // 清除旧的语言类名
        //document.body.classList.remove('lang-yi', 'lang-yuan');
        
        // 根据选择的语言添加对应的类名
        if (lang === 'yi') {
            //document.body.classList.add('lang-yi');
			hideElemByClass('.yuanwen');
			showElemByClass('.yiwen');
			
			changeElemClass('.yiwen',"translation","original");
        } else if (lang === 'yuan') {
			hideElemByClass('.yiwen');
			showElemByClass('.yuanwen');
			
			changeElemClass('.yuanwen',"translation","original");
			
        }else {
			showElemByClass('.yiwen');
			showElemByClass('.yuanwen');
			
			changeElemClass('.yiwen',"original","translation");
			changeElemClass('.yuanwen',"translation","original");
		}
        // 如果是 bilingual，则不加任何类名，保持默认的双语对照显示
    }

    // 4. 动态生成悬浮层 HTML 结构
    function createSwitcherHTML(lang) {
        const config = langConfig[lang] || langConfig['bilingual'];
        let menuItems = '';
        
        for (const [code, data] of Object.entries(langConfig)) {
            const activeClass = code === lang ? 'active' : '';
            menuItems += `<li><a class="dropdown-item ${activeClass}" href="#" data-lang="${code}">${data.name}</a></li>`;
        }

        return `
            <div class="lang-switcher dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" id="langDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                    ${config.label}
                </button>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="langDropdown">
                    ${menuItems}
                </ul>
            </div>
        `;
    }

    // 5. 渲染组件并绑定事件
    function renderSwitcher() {
        const oldSwitcher = document.querySelector('.lang-switcher');
        if (oldSwitcher) oldSwitcher.remove();

        document.body.insertAdjacentHTML('beforeend', createSwitcherHTML(currentLang));
        
        // 绑定点击事件
        document.querySelectorAll('.dropdown-item[data-lang]').forEach(item => {
            item.addEventListener('click', function (e) {
                e.preventDefault();
                const selectedLang = this.getAttribute('data-lang');
                if (selectedLang === currentLang) return;

                currentLang = selectedLang;
                localStorage.setItem('doc-lang', currentLang);
                
                applyLanguage(currentLang); // 应用语言过滤
                renderSwitcher();           // 更新悬浮层UI
            });
        });
    }


	function hideElemByClass(name){
		let aElem = document.querySelectorAll(name);
		// 将NodeList转换为数组，然后使用forEach遍历并隐藏元素
		Array.from(aElem).forEach(function(element) {
			element.style.display = 'none';
		});
	}
	
	function showElemByClass(name){
		let aElem = document.querySelectorAll(name);
		// 将NodeList转换为数组，然后使用forEach遍历并隐藏元素
		Array.from(aElem).forEach(function(element) {
			element.style.display = 'block';
		});
	}
	
	function changeElemClass(elemName,rmName,addName){
		let elem = document.querySelectorAll(elemName);
		Array.from(elem).forEach(function(element) {
			element.classList.remove(rmName);
			element.classList.add(addName);
		});
	}
    // 6. 初始化执行
    applyLanguage(currentLang);
    renderSwitcher();
});