var xstSearchTpl=[
'<div style="padding:10px;">',
	'<div style="width:100%;display: flex;align-items: flex-start;">',
	'<b>搜索的文本：</b><textarea id="xymTlTextSearch" style="height:60px;width:300px;border:1px solid #e3e3e3;"></textarea>',
	'<span style="color:red;padding-left:10px;padding-right:10px;">（可使用正则表达式搜索）</span>',
	'<input type="button" value="搜索" onclick="xymSearchData();" style="background-color: #16baaa;color: #fff;white-space: nowrap;text-align: center;padding: 5px;border: 1px solid transparent;border-radius: 2px;cursor: pointer;"/>',
	'</div>',
	'	<div style="margin-top:10px;">',
	'		<div style="font-size:14px;font-weight:bold;text-align:center;">-&nbsp;&nbsp;搜索到的内容&nbsp;&nbsp;-</div>',
	'		<div id="xymTlTextSearchResult">',
	'		</div>',
	'	</div>',
	'</div>',
].join("");

var layform;
var layIndex;

$(function(){
	

let footerHtml=  '<div class="help-doc-desc" >'+
   '本文档使用AI翻译(手工修正部分)，如需修正，可使用此开源项目：<a href="https://gitee.com/edadmin/xym-translate-jcef1.git" target="_blank">xym-translate-jcef1</a>，如需删除本段文字，请删除/修改根目录下 js/xst-lg.js 中的本段文本'+
  '</div>';

if($("footer").length>0){
	$("footer").last().append(footerHtml);
}else{
	$("body").append(footerHtml);
}
	
});


function changeSel(val){
	console.log(val);
	if(!val){
		val="zh-en";
	}

	if(val==='zh'){
		$('[lg_zh]').show();
		$('[lg_zh]').removeClass("ts-color");
		$('[lg_kh]').hide();
		$('[lg_en]').hide();
	}else if(val==='en'){
		$('[lg_zh]').hide();

		$('[lg_en]').show();
	}else{
		$('[lg_zh]').addClass("ts-color");
		$('[lg_zh]').show();
		$('[lg_kh]').show();
		$('[lg_en]').show();
	}

}


function openSearchView(){
	layer.open({
		type: 1,
		title:'文本搜索',
		area: ['95%', '95%'],
		content:xstSearchTpl
	});
}

function xymSearchData(){
	if(typeof(xstSearchData)=="undefined"){
		var script = document.createElement('script');
		script.type = 'text/javascript';

		script.src = xstPathPre+"xst-search-data.js";
		document.head.appendChild(script);
		
	}
	let txt=$("#xymTlTextSearch").val();
	if(txt==""){
		layer.msg("请输入需要搜索的内容");
		return;
	}
	layIndex= layer.load();
	
	$("#xymTlTextSearchResult").html("");
	
	setTimeout(function(){
		try{
			let flag=false;
			for(let i=0;i<xstSearchData.length;i++){
				let list=xymSearchTxtData(txt,xstSearchData[i].data);
				//console.log(xstSearchData[i].path);
				//console.log(list);
				
				if(list.length>0){
					let $html='<fieldset style="font-size:14px;padding:5px;"><legend style="font-size:12px;font-weight:bold;">'+xstSearchData[i].path+'</legend>';
					for(let j=0;j<list.length;j++){
						$html+='<div style="font-size:12px;"><a href="'+xstPathPre+xstSearchData[i].path+'#xym_tl_'+list[j].id+'" target="_blank">'+list[j].old+'</a></div>';
						$html+='<div style="font-size:12px;"><a href="'+xstPathPre+xstSearchData[i].path+'#xym_tl_'+list[j].id+'" target="_blank" style="color:green;">'+list[j].tl+'</a></div>';
						$html+='<hr>';
					}
					flag=true;
					
					$html+='</fieldset>';
					$("#xymTlTextSearchResult").append($html);
				}
			}
			
			if(!flag) {
				$("#xymTlTextSearchResult").html("<span style='color:red'>未搜索到数据</span>");
			}
		}catch(e){
		}
		layer.close(layIndex);
		
	},500);
	
}

let TAG_START="[xym_search_tag_start]";
let TAG_END="[xym_search_tag_end]";

function xymSearchTxtData(txt,list){
	let rgx=new RegExp(txt,"g");
	
	let data=[];
	if(list!=null && list.length>0){
		for(let i=0;i<list.length;i++){
			let txt1=xymSearchMatchTxt(list[i].old,rgx);
			let txt2=xymSearchMatchTxt(list[i].tl,rgx);
			
			
			if(txt1!="" || txt2!=""){
				
				if(txt1=="") txt1=list[i].old.replace(/\</g,"&lt;");
				if(txt2=="") txt2=list[i].tl.replace(/\</g,"&lt;");
				data[data.length]={old:txt1,tl:txt2,id:list[i].id};
			}
		}
	}
	return data;
}

function xymSearchMatchTxt(data,rgx){
	try{
		let matches = Array.from(data.matchAll(rgx));
		
		if(matches.length==0){
			return "";
		}
		
		let d1="";
		let startIndex=0;
		for (let match of matches) {
			
			d1+=data.substring(startIndex,match.index)+TAG_START;
			d1+=match[0];
			d1+=TAG_END;
			startIndex=match.index+match[0].length;
		}
		d1+=data.substring(startIndex);
		
		data=d1.replace(/\</g,"&lt;");
		data=data.replace(/\[xym_search_tag_start\]/g,"<span style='color:red'>");
		data=data.replace(/\[xym_search_tag_end\]/g,"</span>");
		return data;
	}catch(e){
		return "";
	}
}



document.addEventListener('DOMContentLoaded', () => {
	// 1. 动态注入 CSS 样式
	const css = `
		.floating-menu {
			position: fixed;
			right: 20px;
			top: 50%;
			transform: translateY(-50%);
			background: #ffffff;
			border-radius: 10px;
			box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
			z-index: 1000;
			display: flex;
			flex-direction: column;
			align-items: center;
			overflow: hidden; 
			transition: all 0.3s ease;
		}
		.menu-trigger {
			padding: 10px 14px;
			cursor: pointer;
			color: #666;
			transition: background-color 0.3s, color 0.3s;
			width: 100%;
			text-align: center;
			box-sizing: border-box;
			display: flex;
			justify-content: center;
			align-items: center;
		}
		.menu-trigger:hover { background-color: #eef2ff; color: #4f46e5; }
		
		/* 纯 CSS 汉堡菜单图标 */
		.trigger-icon {
			width: 18px; height: 14px; position: relative;
		}
		.trigger-icon span, .trigger-icon::before, .trigger-icon::after {
			content: ''; position: absolute; left: 0; width: 100%; height: 2px;
			background-color: currentColor; transition: all 0.3s ease;
		}
		.trigger-icon span { top: 50%; transform: translateY(-50%); }
		.trigger-icon::before { top: 0; }
		.trigger-icon::after { bottom: 0; }
		.floating-menu.is-expanded .trigger-icon span { opacity: 0; }
		.floating-menu.is-expanded .trigger-icon::before { top: 50%; transform: translateY(-50%) rotate(45deg); }
		.floating-menu.is-expanded .trigger-icon::after { bottom: 50%; transform: translateY(50%) rotate(-45deg); }

		/* 菜单内容区 */
		.menu-content {
			max-height: 0; opacity: 0;
			transition: max-height 0.3s ease, opacity 0.3s ease; width: 100%;
		}
		.floating-menu.is-expanded .menu-content { max-height: 500px; opacity: 1; }

		/* 菜单项 */
		.menu-item {
			padding: 7px 16px; cursor: pointer; color: #555; font-size: 13px;
			transition: all 0.2s ease; width: 100%; box-sizing: border-box;
			display: flex; align-items: center; gap: 8px; justify-content: center;
			white-space: nowrap; position: relative;
		}
		.menu-item:hover { background-color: #eef2ff; color: #4f46e5; }
		.menu-item.active { background-color: #eef2ff; color: #4f46e5; font-weight: 600; }
		.menu-item.active::before {
			content: ''; position: absolute; left: 0; top: 50%; transform: translateY(-50%);
			width: 3px; height: 60%; background-color: #4f46e5; border-radius: 0 3px 3px 0;
		}

		/* 纯 CSS 搜索图标 */
		.icon-search {
			width: 12px; height: 12px; border: 2px solid currentColor; border-radius: 50%;
			position: relative; display: inline-block;
		}
		.icon-search::after {
			content: ''; position: absolute; bottom: -5px; right: -5px;
			width: 2px; height: 6px; background-color: currentColor; transform: rotate(-45deg);
		}

		/* 分隔符 */
		.menu-divider {
			width: 80%; height: 1px; background-color: #e5e7eb; margin: 3px auto;
		}
	`;
	const styleEl = document.createElement('style');
	styleEl.textContent = css;
	document.head.appendChild(styleEl);

	// 2. 动态创建菜单 DOM 结构
	const menuData = [
		{ label: '中文', action: 'zh' },
		{ label: '英文', action: 'en' },
		{ label: '中英文', action: 'zh-en' },
		{ type: 'divider' },
		{ label: '搜索', action: 'search', icon: 'search' }
	];

	const menuContainer = document.createElement('div');
	menuContainer.className = 'floating-menu is-expanded';
	menuContainer.id = 'floatingMenu';

	const trigger = document.createElement('div');
	trigger.className = 'menu-trigger';
	trigger.id = 'menuTrigger';
	trigger.innerHTML = '<div class="trigger-icon"><span></span></div>';

	const content = document.createElement('div');
	content.className = 'menu-content';

	menuData.forEach(item => {
		const el = document.createElement('div');
		if (item.type === 'divider') {
			el.className = 'menu-divider';
		} else {
			el.className = 'menu-item';
			el.dataset.action = item.action;
			let iconHtml = item.icon === 'search' ? '<span class="icon-search"></span>' : '';
			el.innerHTML = `${iconHtml}<span>${item.label}</span>`;
		}
		content.appendChild(el);
	});

	menuContainer.appendChild(trigger);
	menuContainer.appendChild(content);
	document.body.appendChild(menuContainer);

	// 3. 绑定交互逻辑
	const menuItems = menuContainer.querySelectorAll('.menu-item');
	const MENU_STATE_KEY = 'floatingMenuState';
	const ACTIVE_ITEM_KEY = 'activeFloatingMenuItem';

	// 恢复状态
	if (localStorage.getItem(MENU_STATE_KEY) === 'collapsed') {
		menuContainer.classList.remove('is-expanded');
	}
	let savedAction = localStorage.getItem(ACTIVE_ITEM_KEY);
	if(!savedAction){
		savedAction="zh-en";
	}

	const targetItem = menuContainer.querySelector(`[data-action="${savedAction}"]`);
	if (targetItem){
		targetItem.classList.add('active');
		changeSel(savedAction);
	}


	// 展开/收起
	trigger.addEventListener('click', () => {
		const isExpanded = menuContainer.classList.toggle('is-expanded');
		localStorage.setItem(MENU_STATE_KEY, isExpanded ? 'expanded' : 'collapsed');
	});

	// 点击菜单项
	menuContainer.addEventListener('click', (event) => {
		const menuItem = event.target.closest('.menu-item');
		if (!menuItem) return;

		const action = menuItem.dataset.action;

		// 【核心修改】：如果点击的是搜索，只执行动作，不记录状态和高亮
		if (action === 'search') {
			openSearchView();
			// 在这里可以添加你的搜索弹窗或跳转逻辑
			return; // 直接返回，不执行下面的高亮和存储逻辑
		}

		// 其他菜单项（如语言切换）的正常逻辑
		menuItems.forEach(item => item.classList.remove('active'));
		menuItem.classList.add('active');
		localStorage.setItem(ACTIVE_ITEM_KEY, action);
		
		changeSel(action);
	});
});